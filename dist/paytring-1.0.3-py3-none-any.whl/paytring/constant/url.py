class URL:
    BASE_URL = "https://api.paytring.com/api/v1/"
    ORDER_CREATE = "https://api.paytring.com/api/v1/order/create"
    FETCH_ORDER = "https://api.paytring.com/api/v1/order/fetch"
    FETCH_ORDER_BY_RECIEPT = "https://api.paytring.com/api/v1/order/fetch/receipt"
    REFUND = "https://api.paytring.com/api/v1/order/refund"